﻿
namespace Assignment1___Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num0 = new System.Windows.Forms.Button();
            this.Period = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.Plusminswap = new System.Windows.Forms.Button();
            this.num1 = new System.Windows.Forms.Button();
            this.num2 = new System.Windows.Forms.Button();
            this.num6 = new System.Windows.Forms.Button();
            this.num5 = new System.Windows.Forms.Button();
            this.num4 = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.num3 = new System.Windows.Forms.Button();
            this.CE = new System.Windows.Forms.Button();
            this.Multi = new System.Windows.Forms.Button();
            this.num9 = new System.Windows.Forms.Button();
            this.num8 = new System.Windows.Forms.Button();
            this.num7 = new System.Windows.Forms.Button();
            this.Subtract = new System.Windows.Forms.Button();
            this.Del = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.DivideX = new System.Windows.Forms.Button();
            this.XtoYpow = new System.Windows.Forms.Button();
            this.Squared = new System.Windows.Forms.Button();
            this.Sqrt = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // num0
            // 
            this.num0.Location = new System.Drawing.Point(108, 379);
            this.num0.Margin = new System.Windows.Forms.Padding(4);
            this.num0.Name = "num0";
            this.num0.Size = new System.Drawing.Size(68, 50);
            this.num0.TabIndex = 0;
            this.num0.Text = "0";
            this.num0.UseVisualStyleBackColor = true;
            this.num0.Click += new System.EventHandler(this.num0_Click);
            // 
            // Period
            // 
            this.Period.Location = new System.Drawing.Point(184, 379);
            this.Period.Margin = new System.Windows.Forms.Padding(4);
            this.Period.Name = "Period";
            this.Period.Size = new System.Drawing.Size(68, 50);
            this.Period.TabIndex = 1;
            this.Period.Text = ".";
            this.Period.UseVisualStyleBackColor = true;
            this.Period.Click += new System.EventHandler(this.Period_Click);
            // 
            // Equal
            // 
            this.Equal.Location = new System.Drawing.Point(260, 379);
            this.Equal.Margin = new System.Windows.Forms.Padding(4);
            this.Equal.Name = "Equal";
            this.Equal.Size = new System.Drawing.Size(68, 50);
            this.Equal.TabIndex = 2;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = true;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            // 
            // Plusminswap
            // 
            this.Plusminswap.Location = new System.Drawing.Point(32, 379);
            this.Plusminswap.Margin = new System.Windows.Forms.Padding(4);
            this.Plusminswap.Name = "Plusminswap";
            this.Plusminswap.Size = new System.Drawing.Size(68, 50);
            this.Plusminswap.TabIndex = 3;
            this.Plusminswap.Text = "+/-";
            this.Plusminswap.UseVisualStyleBackColor = true;
            this.Plusminswap.Click += new System.EventHandler(this.Plusminswap_Click);
            // 
            // num1
            // 
            this.num1.Location = new System.Drawing.Point(32, 321);
            this.num1.Margin = new System.Windows.Forms.Padding(4);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(68, 50);
            this.num1.TabIndex = 4;
            this.num1.Text = "1";
            this.num1.UseVisualStyleBackColor = true;
            this.num1.Click += new System.EventHandler(this.num1_Click);
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(108, 321);
            this.num2.Margin = new System.Windows.Forms.Padding(4);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(68, 50);
            this.num2.TabIndex = 5;
            this.num2.Text = "2";
            this.num2.UseVisualStyleBackColor = true;
            this.num2.Click += new System.EventHandler(this.num2_Click);
            // 
            // num6
            // 
            this.num6.Location = new System.Drawing.Point(184, 263);
            this.num6.Margin = new System.Windows.Forms.Padding(4);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(68, 50);
            this.num6.TabIndex = 6;
            this.num6.Text = "6";
            this.num6.UseVisualStyleBackColor = true;
            this.num6.Click += new System.EventHandler(this.num6_Click);
            // 
            // num5
            // 
            this.num5.Location = new System.Drawing.Point(108, 263);
            this.num5.Margin = new System.Windows.Forms.Padding(4);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(68, 50);
            this.num5.TabIndex = 7;
            this.num5.Text = "5";
            this.num5.UseVisualStyleBackColor = true;
            this.num5.Click += new System.EventHandler(this.num5_Click);
            // 
            // num4
            // 
            this.num4.Location = new System.Drawing.Point(32, 263);
            this.num4.Margin = new System.Windows.Forms.Padding(4);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(68, 50);
            this.num4.TabIndex = 8;
            this.num4.Text = "4";
            this.num4.UseVisualStyleBackColor = true;
            this.num4.Click += new System.EventHandler(this.num4_Click);
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(260, 321);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(68, 50);
            this.Add.TabIndex = 9;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // num3
            // 
            this.num3.Location = new System.Drawing.Point(184, 321);
            this.num3.Margin = new System.Windows.Forms.Padding(4);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(68, 50);
            this.num3.TabIndex = 10;
            this.num3.Text = "3";
            this.num3.UseVisualStyleBackColor = true;
            this.num3.Click += new System.EventHandler(this.num3_Click);
            // 
            // CE
            // 
            this.CE.Location = new System.Drawing.Point(32, 147);
            this.CE.Margin = new System.Windows.Forms.Padding(4);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(68, 50);
            this.CE.TabIndex = 11;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = true;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // Multi
            // 
            this.Multi.Location = new System.Drawing.Point(259, 205);
            this.Multi.Margin = new System.Windows.Forms.Padding(4);
            this.Multi.Name = "Multi";
            this.Multi.Size = new System.Drawing.Size(68, 50);
            this.Multi.TabIndex = 12;
            this.Multi.Text = "X";
            this.Multi.UseVisualStyleBackColor = true;
            this.Multi.Click += new System.EventHandler(this.Multi_Click);
            // 
            // num9
            // 
            this.num9.Location = new System.Drawing.Point(184, 205);
            this.num9.Margin = new System.Windows.Forms.Padding(4);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(68, 50);
            this.num9.TabIndex = 13;
            this.num9.Text = "9";
            this.num9.UseVisualStyleBackColor = true;
            this.num9.Click += new System.EventHandler(this.button14_Click);
            // 
            // num8
            // 
            this.num8.Location = new System.Drawing.Point(108, 205);
            this.num8.Margin = new System.Windows.Forms.Padding(4);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(68, 50);
            this.num8.TabIndex = 14;
            this.num8.Text = "8";
            this.num8.UseVisualStyleBackColor = true;
            this.num8.Click += new System.EventHandler(this.num8_Click);
            // 
            // num7
            // 
            this.num7.Location = new System.Drawing.Point(32, 205);
            this.num7.Margin = new System.Windows.Forms.Padding(4);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(68, 50);
            this.num7.TabIndex = 15;
            this.num7.Text = "7";
            this.num7.UseVisualStyleBackColor = true;
            this.num7.Click += new System.EventHandler(this.num7_Click);
            // 
            // Subtract
            // 
            this.Subtract.Location = new System.Drawing.Point(259, 263);
            this.Subtract.Margin = new System.Windows.Forms.Padding(4);
            this.Subtract.Name = "Subtract";
            this.Subtract.Size = new System.Drawing.Size(68, 50);
            this.Subtract.TabIndex = 16;
            this.Subtract.Text = "-";
            this.Subtract.UseVisualStyleBackColor = true;
            this.Subtract.Click += new System.EventHandler(this.subtract_Click);
            // 
            // Del
            // 
            this.Del.Location = new System.Drawing.Point(184, 147);
            this.Del.Margin = new System.Windows.Forms.Padding(4);
            this.Del.Name = "Del";
            this.Del.Size = new System.Drawing.Size(68, 50);
            this.Del.TabIndex = 17;
            this.Del.Text = "Del.";
            this.Del.UseVisualStyleBackColor = true;
            this.Del.Click += new System.EventHandler(this.Del_Click);
            // 
            // C
            // 
            this.C.Location = new System.Drawing.Point(108, 147);
            this.C.Margin = new System.Windows.Forms.Padding(4);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(68, 50);
            this.C.TabIndex = 18;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = true;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // Divide
            // 
            this.Divide.Location = new System.Drawing.Point(260, 147);
            this.Divide.Margin = new System.Windows.Forms.Padding(4);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(68, 50);
            this.Divide.TabIndex = 19;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = true;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // DivideX
            // 
            this.DivideX.Location = new System.Drawing.Point(260, 89);
            this.DivideX.Margin = new System.Windows.Forms.Padding(4);
            this.DivideX.Name = "DivideX";
            this.DivideX.Size = new System.Drawing.Size(68, 50);
            this.DivideX.TabIndex = 20;
            this.DivideX.Text = "1/x";
            this.DivideX.UseVisualStyleBackColor = true;
            this.DivideX.Click += new System.EventHandler(this.DivideX_Click);
            // 
            // XtoYpow
            // 
            this.XtoYpow.Location = new System.Drawing.Point(184, 89);
            this.XtoYpow.Margin = new System.Windows.Forms.Padding(4);
            this.XtoYpow.Name = "XtoYpow";
            this.XtoYpow.Size = new System.Drawing.Size(68, 50);
            this.XtoYpow.TabIndex = 21;
            this.XtoYpow.Text = "x^y";
            this.XtoYpow.UseVisualStyleBackColor = true;
            this.XtoYpow.Click += new System.EventHandler(this.XtoYpow_Click);
            // 
            // Squared
            // 
            this.Squared.Location = new System.Drawing.Point(108, 89);
            this.Squared.Margin = new System.Windows.Forms.Padding(4);
            this.Squared.Name = "Squared";
            this.Squared.Size = new System.Drawing.Size(68, 50);
            this.Squared.TabIndex = 22;
            this.Squared.Text = "x^2";
            this.Squared.UseVisualStyleBackColor = true;
            this.Squared.Click += new System.EventHandler(this.Squared_Click);
            // 
            // Sqrt
            // 
            this.Sqrt.Location = new System.Drawing.Point(32, 89);
            this.Sqrt.Margin = new System.Windows.Forms.Padding(4);
            this.Sqrt.Name = "Sqrt";
            this.Sqrt.Size = new System.Drawing.Size(68, 50);
            this.Sqrt.TabIndex = 23;
            this.Sqrt.Text = "Sqrt";
            this.Sqrt.UseVisualStyleBackColor = true;
            this.Sqrt.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(32, 59);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(295, 22);
            this.textBox1.TabIndex = 24;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(32, 29);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(295, 22);
            this.textBox2.TabIndex = 25;
            // 
            // Calculator
            // 
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(358, 464);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Sqrt);
            this.Controls.Add(this.Squared);
            this.Controls.Add(this.XtoYpow);
            this.Controls.Add(this.DivideX);
            this.Controls.Add(this.Divide);
            this.Controls.Add(this.C);
            this.Controls.Add(this.Del);
            this.Controls.Add(this.Subtract);
            this.Controls.Add(this.num7);
            this.Controls.Add(this.num8);
            this.Controls.Add(this.num9);
            this.Controls.Add(this.Multi);
            this.Controls.Add(this.CE);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.num4);
            this.Controls.Add(this.num5);
            this.Controls.Add(this.num6);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.Plusminswap);
            this.Controls.Add(this.Equal);
            this.Controls.Add(this.Period);
            this.Controls.Add(this.num0);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button num0;
        private System.Windows.Forms.Button Period;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Button Plusminswap;
        private System.Windows.Forms.Button num1;
        private System.Windows.Forms.Button num2;
        private System.Windows.Forms.Button num6;
        private System.Windows.Forms.Button num5;
        private System.Windows.Forms.Button num4;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button num3;
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button Multi;
        private System.Windows.Forms.Button num9;
        private System.Windows.Forms.Button num8;
        private System.Windows.Forms.Button num7;
        private System.Windows.Forms.Button Subtract;
        private System.Windows.Forms.Button Del;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button Divide;
        private System.Windows.Forms.Button DivideX;
        private System.Windows.Forms.Button XtoYpow;
        private System.Windows.Forms.Button Squared;
        private System.Windows.Forms.Button Sqrt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}

